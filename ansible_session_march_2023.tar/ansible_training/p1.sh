echo "Sample script"
echo "Working kernel name is:`uname` version:`uname -r`"
echo "VM status:-"
vmstat
echo "--------------Exit from script--------------"
